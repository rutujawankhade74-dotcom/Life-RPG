const sqlite3 = require("sqlite3").verbose();


const db = new sqlite3.Database(
    "./liferpg.db",
    (error) => {

        if (error) {

            console.log(
                "❌ Database error:",
                error
            );

        } else {

            console.log(
                "✅ SQLite Database Connected"
            );

        }

    }
);



// ===============================
// USERS TABLE
// ===============================

db.run(`

    CREATE TABLE IF NOT EXISTS users (

        id INTEGER PRIMARY KEY AUTOINCREMENT,

        username TEXT UNIQUE NOT NULL,

        password TEXT NOT NULL

    )

`);



// ===============================
// CHARACTERS TABLE
// ===============================

db.run(`

    CREATE TABLE IF NOT EXISTS characters (

        id INTEGER PRIMARY KEY AUTOINCREMENT,

        user_id INTEGER,

        name TEXT,

        character_type TEXT,

        level INTEGER DEFAULT 1,

        xp INTEGER DEFAULT 0,

        coins INTEGER DEFAULT 0,

        streak INTEGER DEFAULT 0,

        FOREIGN KEY (user_id)
        REFERENCES users(id)

    )

`);



// ===============================
// QUESTS TABLE
// ===============================

db.run(`

    CREATE TABLE IF NOT EXISTS quests (

        id INTEGER PRIMARY KEY AUTOINCREMENT,

        user_id INTEGER,

        title TEXT NOT NULL,

        category TEXT,

        xp INTEGER DEFAULT 0,

        coins INTEGER DEFAULT 0,

        completed INTEGER DEFAULT 0,

        created_at TEXT,

        FOREIGN KEY (user_id)
        REFERENCES users(id)

    )

`);



module.exports = db;