const sqlite3 = require("sqlite3").verbose();

const db = new sqlite3.Database("./liferpg.db", (error) => {
    if (error) {
        console.error("Database connection failed:", error.message);
    } else {
        console.log("Connected to liferpg.db");
    }
});

db.serialize(() => {
    db.run(`
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT UNIQUE NOT NULL,
            password TEXT NOT NULL,
            level INTEGER DEFAULT 1,
            xp INTEGER DEFAULT 0,
            coins INTEGER DEFAULT 0,
            streak INTEGER DEFAULT 0,
            last_completed_date TEXT
        )
    `);

    db.run(`
        CREATE TABLE IF NOT EXISTS characters (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            character_class TEXT NOT NULL,
            strength INTEGER DEFAULT 10,
            intelligence INTEGER DEFAULT 10,
            agility INTEGER DEFAULT 10,
            FOREIGN KEY (user_id) REFERENCES users(id)
        )
    `);

    db.run(`
        CREATE TABLE IF NOT EXISTS quests (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            title TEXT NOT NULL,
            category TEXT DEFAULT 'General',
            xp INTEGER DEFAULT 20,
            coins INTEGER DEFAULT 10,
            completed INTEGER DEFAULT 0,
            completed_at TEXT,
            FOREIGN KEY (user_id) REFERENCES users(id)
        )
    `);

    db.run(`
        CREATE TABLE IF NOT EXISTS rewards (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            cost INTEGER NOT NULL
        )
    `);

    db.run(`
        CREATE TABLE IF NOT EXISTS purchases (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            reward_id INTEGER NOT NULL,
            purchased_at TEXT,
            FOREIGN KEY (user_id) REFERENCES users(id),
            FOREIGN KEY (reward_id) REFERENCES rewards(id)
        )
    `);

    db.run(`
        INSERT OR IGNORE INTO rewards (id, name, cost)
        VALUES
        (1, 'Watch one episode', 100),
        (2, 'Play a game for 30 minutes', 150),
        (3, 'Eat your favourite snack', 200),
        (4, 'Take a relaxing break', 250)
    `);
});

module.exports = db;