const express = require("express");
const cors = require("cors");
const db = require("./database");

const app = express();
const PORT = 5000;

app.use(cors());
app.use(express.json());

app.get("/", (req, res) => {
    res.send("Life RPG backend is running");
});

// SIGNUP
app.post("/signup", (req, res) => {
    const { username, password } = req.body;

    if (!username || !password) {
        return res.status(400).json({
            message: "Username and password are required"
        });
    }

    const sql = `
        INSERT INTO users (username, password)
        VALUES (?, ?)
    `;

    db.run(sql, [username, password], function (error) {
        if (error) {
            return res.status(400).json({
                message: "Username already exists"
            });
        }

        res.json({
            message: "Account created successfully",
            userId: this.lastID
        });
    });
});

// LOGIN
app.post("/login", (req, res) => {
    const { username, password } = req.body;

    db.get(
        `SELECT * FROM users WHERE username = ? AND password = ?`,
        [username, password],
        (error, user) => {
            if (error) {
                return res.status(500).json({
                    message: "Database error"
                });
            }

            if (!user) {
                return res.status(401).json({
                    message: "Invalid username or password"
                });
            }

            res.json({
                message: "Login successful",
                userId: user.id,
                username: user.username
            });
        }
    );
});

// SAVE CHARACTER
app.post("/character", (req, res) => {
    const { userId, characterClass } = req.body;

    let strength = 10;
    let intelligence = 10;
    let agility = 10;

    if (characterClass === "Warrior") {
        strength = 18;
        intelligence = 8;
        agility = 12;
    } else if (characterClass === "Mage") {
        strength = 8;
        intelligence = 18;
        agility = 12;
    } else if (characterClass === "Ranger") {
        strength = 12;
        intelligence = 10;
        agility = 18;
    }

    db.run(
        `DELETE FROM characters WHERE user_id = ?`,
        [userId],
        () => {
            db.run(
                `
                INSERT INTO characters
                (user_id, character_class, strength, intelligence, agility)
                VALUES (?, ?, ?, ?, ?)
                `,
                [
                    userId,
                    characterClass,
                    strength,
                    intelligence,
                    agility
                ],
                function (error) {
                    if (error) {
                        return res.status(500).json({
                            message: "Character could not be saved"
                        });
                    }

                    res.json({
                        message: "Character saved successfully",
                        characterId: this.lastID
                    });
                }
            );
        }
    );
});

// GET PLAYER DATA
app.get("/player/:userId", (req, res) => {
    const userId = req.params.userId;

    db.get(
        `
        SELECT
            users.*,
            characters.character_class,
            characters.strength,
            characters.intelligence,
            characters.agility
        FROM users
        LEFT JOIN characters
        ON users.id = characters.user_id
        WHERE users.id = ?
        `,
        [userId],
        (error, player) => {
            if (error) {
                return res.status(500).json({
                    message: "Could not load player"
                });
            }

            if (!player) {
                return res.status(404).json({
                    message: "Player not found"
                });
            }

            res.json(player);
        }
    );
});

// ADD QUEST
app.post("/quests", (req, res) => {
    const {
        userId,
        title,
        category,
        xp,
        coins
    } = req.body;

    if (!userId || !title) {
        return res.status(400).json({
            message: "Quest title is required"
        });
    }

    db.run(
        `
        INSERT INTO quests
        (user_id, title, category, xp, coins)
        VALUES (?, ?, ?, ?, ?)
        `,
        [
            userId,
            title,
            category || "General",
            xp || 20,
            coins || 10
        ],
        function (error) {
            if (error) {
                return res.status(500).json({
                    message: "Quest could not be added"
                });
            }

            res.json({
                message: "Quest added successfully",
                questId: this.lastID
            });
        }
    );
});

// GET QUESTS
app.get("/quests/:userId", (req, res) => {
    db.all(
        `SELECT * FROM quests WHERE user_id = ? ORDER BY id DESC`,
        [req.params.userId],
        (error, quests) => {
            if (error) {
                return res.status(500).json({
                    message: "Could not load quests"
                });
            }

            res.json(quests);
        }
    );
});

// COMPLETE QUEST
app.post("/quests/:questId/complete", (req, res) => {
    const questId = req.params.questId;

    db.get(
        `SELECT * FROM quests WHERE id = ?`,
        [questId],
        (error, quest) => {
            if (error || !quest) {
                return res.status(404).json({
                    message: "Quest not found"
                });
            }

            if (quest.completed === 1) {
                return res.status(400).json({
                    message: "Quest already completed"
                });
            }

            db.run(
                `
                UPDATE quests
                SET completed = 1, completed_at = ?
                WHERE id = ?
                `,
                [new Date().toISOString(), questId],
                (updateError) => {
                    if (updateError) {
                        return res.status(500).json({
                            message: "Quest update failed"
                        });
                    }

                    db.get(
                        `SELECT * FROM users WHERE id = ?`,
                        [quest.user_id],
                        (userError, user) => {
                            if (userError || !user) {
                                return res.status(500).json({
                                    message: "User not found"
                                });
                            }

                            const newXP = user.xp + quest.xp;
                            const newCoins = user.coins + quest.coins;
                            const newLevel = Math.floor(newXP / 100) + 1;

                            const today = new Date()
                                .toISOString()
                                .split("T")[0];

                            let newStreak = user.streak;

                            if (user.last_completed_date !== today) {
                                newStreak = user.streak + 1;
                            }

                            db.run(
                                `
                                UPDATE users
                                SET xp = ?,
                                    coins = ?,
                                    level = ?,
                                    streak = ?,
                                    last_completed_date = ?
                                WHERE id = ?
                                `,
                                [
                                    newXP,
                                    newCoins,
                                    newLevel,
                                    newStreak,
                                    today,
                                    quest.user_id
                                ],
                                (finalError) => {
                                    if (finalError) {
                                        return res.status(500).json({
                                            message: "Player update failed"
                                        });
                                    }

                                    res.json({
                                        message: "Quest completed",
                                        xp: newXP,
                                        coins: newCoins,
                                        level: newLevel,
                                        streak: newStreak
                                    });
                                }
                            );
                        }
                    );
                }
            );
        }
    );
});

// GET REWARDS
app.get("/rewards", (req, res) => {
    db.all(`SELECT * FROM rewards`, [], (error, rewards) => {
        if (error) {
            return res.status(500).json({
                message: "Could not load rewards"
            });
        }

        res.json(rewards);
    });
});

// BUY REWARD
app.post("/rewards/:rewardId/buy", (req, res) => {
    const rewardId = req.params.rewardId;
    const { userId } = req.body;

    db.get(
        `SELECT * FROM rewards WHERE id = ?`,
        [rewardId],
        (rewardError, reward) => {
            if (rewardError || !reward) {
                return res.status(404).json({
                    message: "Reward not found"
                });
            }

            db.get(
                `SELECT * FROM users WHERE id = ?`,
                [userId],
                (userError, user) => {
                    if (userError || !user) {
                        return res.status(404).json({
                            message: "User not found"
                        });
                    }

                    if (user.coins < reward.cost) {
                        return res.status(400).json({
                            message: "Not enough coins"
                        });
                    }

                    db.run(
                        `UPDATE users SET coins = coins - ? WHERE id = ?`,
                        [reward.cost, userId],
                        (updateError) => {
                            if (updateError) {
                                return res.status(500).json({
                                    message: "Purchase failed"
                                });
                            }

                            db.run(
                                `
                                INSERT INTO purchases
                                (user_id, reward_id, purchased_at)
                                VALUES (?, ?, ?)
                                `,
                                [
                                    userId,
                                    rewardId,
                                    new Date().toISOString()
                                ],
                                () => {
                                    res.json({
                                        message: "Reward purchased successfully"
                                    });
                                }
                            );
                        }
                    );
                }
            );
        }
    );
});

app.listen(PORT, () => {
    console.log(`Server running on http://localhost:${PORT}`);
});
