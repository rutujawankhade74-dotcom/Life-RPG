const express = require("express");

const cors = require("cors");

const bcrypt = require("bcryptjs");

const db = require("./database");


const app = express();

const PORT = 5000;



// ==================================
// MIDDLEWARE
// ==================================

app.use(cors());

app.use(express.json());



// ==================================
// HOME
// ==================================

app.get("/", (req, res) => {

    res.send(
        "⚔️ LIFE RPG BACKEND IS WORKING!"
    );

});



// ==================================
// SIGNUP
// ==================================

app.post("/signup", async (req, res) => {


    const {
        username,
        password
    } = req.body;


    if (!username || !password) {

        return res.status(400).json({

            message:
                "Please enter username and password"

        });

    }


    try {


        // Check existing user

        db.get(

            "SELECT * FROM users WHERE username = ?",

            [username],

            async (error, user) => {


                if (error) {

                    return res.status(500).json({

                        message:
                            "Database error"

                    });

                }


                if (user) {

                    return res.status(400).json({

                        message:
                            "Username already exists"

                    });

                }


                // Encrypt password

                const hashedPassword =
                    await bcrypt.hash(
                        password,
                        10
                    );


                // Insert user

                db.run(

                    `INSERT INTO users
                    (username, password)
                    VALUES (?, ?)`,

                    [
                        username,
                        hashedPassword
                    ],

                    function(error) {


                        if (error) {

                            return res.status(500).json({

                                message:
                                    "Could not create user"

                            });

                        }


                        res.json({

                            message:
                                "✅ Signup successful!",

                            userId:
                                this.lastID

                        });

                    }

                );

            }

        );


    } catch (error) {

        res.status(500).json({

            message:
                "Server error"

        });

    }

});



// ==================================
// LOGIN
// ==================================

app.post("/login", (req, res) => {


    const {
        username,
        password
    } = req.body;


    if (!username || !password) {

        return res.status(400).json({

            message:
                "Please enter username and password"

        });

    }


    db.get(

        "SELECT * FROM users WHERE username = ?",

        [username],

        async (error, user) => {


            if (error) {

                return res.status(500).json({

                    message:
                        "Database error"

                });

            }


            if (!user) {

                return res.status(401).json({

                    message:
                        "Invalid username or password"

                });

            }


            // Compare password

            const passwordMatch =
                await bcrypt.compare(

                    password,

                    user.password

                );


            if (!passwordMatch) {

                return res.status(401).json({

                    message:
                        "Invalid username or password"

                });

            }


            res.json({

                message:
                    "✅ Login successful!",

                userId:
                    user.id,

                username:
                    user.username

            });

        }

    );

});



// ==================================
// DATABASE TEST
// ==================================

app.get(
    "/test-database",
    (req, res) => {


        db.get(

            `SELECT name
             FROM sqlite_master
             WHERE type='table'
             LIMIT 1`,

            (error, row) => {


                if (error) {

                    return res.status(500).json({

                        message:
                            "Database error",

                        error:
                            error.message

                    });

                }


                res.json({

                    message:
                        "✅ Database is working!",

                    table:
                        row

                });

            }

        );

    }

);



// ==================================
// START SERVER
// ==================================

app.listen(

    PORT,

    () => {

        console.log(
            "================================"
        );

        console.log(
            "⚔️ LIFE RPG SERVER STARTED"
        );

        console.log(
            "🌐 http://localhost:5000"
        );

        console.log(
            "================================"
        );

    }

);