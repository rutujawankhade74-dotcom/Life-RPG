const express = require("express");

const cors = require("cors");

const bcrypt = require("bcryptjs");

const db = require("./database");


const app = express();

const PORT = 5000;



// ==================================
// MIDDLEWARE
// ==================================

app.use(cors());

app.use(express.json());



// ==================================
// HOME
// ==================================

app.get("/", (req, res) => {

    res.send(
        "⚔️ LIFE RPG BACKEND IS WORKING!"
    );

});



// ==================================
// SIGNUP
// ==================================

app.post("/signup", async (req, res) => {


    const {
        username,
        password
    } = req.body;


    if (!username || !password) {

        return res.status(400).json({

            message:
                "Please enter username and password"

        });

    }


    try {


        // Check existing user

        db.get(

            "SELECT * FROM users WHERE username = ?",

            [username],

            async (error, user) => {


                if (error) {

                    return res.status(500).json({

                        message:
                            "Database error"

                    });

                }


                if (user) {

                    return res.status(400).json({

                        message:
                            "Username already exists"

                    });

                }


                // Encrypt password

                const hashedPassword =
                    await bcrypt.hash(
                        password,
                        10
                    );


                // Insert user

                db.run(

                    `INSERT INTO users
                    (username, password)
                    VALUES (?, ?)`,

                    [
                        username,
                        hashedPassword
                    ],

                    function(error) {


                        if (error) {

                            return res.status(500).json({

                                message:
                                    "Could not create user"

                            });

                        }


                        res.json({

                            message:
                                "✅ Signup successful!",

                            userId:
                                this.lastID

                        });

                    }

                );

            }

        );


    } catch (error) {

        res.status(500).json({

            message:
                "Server error"

        });

    }

});



// ==================================
// LOGIN
// ==================================

app.post("/login", (req, res) => {


    const {
        username,
        password
    } = req.body;


    if (!username || !password) {

        return res.status(400).json({

            message:
                "Please enter username and password"

        });

    }


    db.get(

        "SELECT * FROM users WHERE username = ?",

        [username],

        async (error, user) => {


            if (error) {

                return res.status(500).json({

                    message:
                        "Database error"

                });

            }


            if (!user) {

                return res.status(401).json({

                    message:
                        "Invalid username or password"

                });

            }


            // Compare password

            const passwordMatch =
                await bcrypt.compare(

                    password,

                    user.password

                );


            if (!passwordMatch) {

                return res.status(401).json({

                    message:
                        "Invalid username or password"

                });

            }


            res.json({

                message:
                    "✅ Login successful!",

                userId:
                    user.id,

                username:
                    user.username

            });

        }

    );

});



// ==================================
// DATABASE TEST
// ==================================

app.get(
    "/test-database",
    (req, res) => {


        db.get(

            `SELECT name
             FROM sqlite_master
             WHERE type='table'
             LIMIT 1`,

            (error, row) => {


                if (error) {

                    return res.status(500).json({

                        message:
                            "Database error",

                        error:
                            error.message

                    });

                }


                res.json({

                    message:
                        "✅ Database is working!",

                    table:
                        row

                });

            }

        );

    }

);



// ==================================
// START SERVER
// ==================================

app.listen(

    PORT,

    () => {

        console.log(
            "================================"
        );

        console.log(
            "⚔️ LIFE RPG SERVER STARTED"
        );

        console.log(
            "🌐 http://localhost:5000"
        );

        console.log(
            "================================"
        );

    }

);
// ==========================================
// CREATE CHARACTER AFTER LOGIN
// ==========================================

app.post("/character", (req, res) => {

    const {
        userId,
        characterType
    } = req.body;

    if (!userId || !characterType) {
        return res.status(400).json({
            message: "User ID and character type are required"
        });
    }

    db.run(
        `
        INSERT OR IGNORE INTO characters
        (user_id, character_type)
        VALUES (?, ?)
        `,
        [userId, characterType],
        function(error) {

            if (error) {
                return res.status(500).json({
                    message: "Could not create character",
                    error: error.message
                });
            }

            res.json({
                message: "Character saved successfully"
            });
        }
    );
});


// ==========================================
// GET PLAYER DATA
// ==========================================

app.get("/player/:userId", (req, res) => {

    const userId = req.params.userId;

    db.get(
        `
        SELECT
            users.username,
            characters.*
        FROM users
        LEFT JOIN characters
        ON users.id = characters.user_id
        WHERE users.id = ?
        `,
        [userId],
        (error, player) => {

            if (error) {
                return res.status(500).json({
                    message: "Could not load player data"
                });
            }

            if (!player) {
                return res.status(404).json({
                    message: "Player not found"
                });
            }

            res.json(player);
        }
    );
});


// ==========================================
// ADD QUEST
// ==========================================

app.post("/quests", (req, res) => {

    const {
        userId,
        title,
        category,
        xp,
        coins
    } = req.body;

    if (!userId || !title) {
        return res.status(400).json({
            message: "User ID and quest title are required"
        });
    }

    db.run(
        `
        INSERT INTO quests
        (user_id, title, category, xp, coins, created_at)
        VALUES (?, ?, ?, ?, ?, datetime('now'))
        `,
        [
            userId,
            title,
            category || "General",
            xp || 20,
            coins || 10
        ],
        function(error) {

            if (error) {
                return res.status(500).json({
                    message: "Could not add quest"
                });
            }

            res.json({
                message: "Quest added successfully",
                questId: this.lastID
            });
        }
    );
});


// ==========================================
// GET USER QUESTS
// ==========================================

app.get("/quests/:userId", (req, res) => {

    const userId = req.params.userId;

    db.all(
        `
        SELECT *
        FROM quests
        WHERE user_id = ?
        ORDER BY id DESC
        `,
        [userId],
        (error, quests) => {

            if (error) {
                return res.status(500).json({
                    message: "Could not load quests"
                });
            }

            res.json(quests);
        }
    );
});


// ==========================================
// COMPLETE QUEST
// ==========================================

app.put("/quests/:questId/complete", (req, res) => {

    const questId = req.params.questId;

    db.get(
        `
        SELECT *
        FROM quests
        WHERE id = ?
        `,
        [questId],
        (error, quest) => {

            if (error) {
                return res.status(500).json({
                    message: "Database error"
                });
            }

            if (!quest) {
                return res.status(404).json({
                    message: "Quest not found"
                });
            }

            if (quest.completed === 1) {
                return res.status(400).json({
                    message: "Quest already completed"
                });
            }

            db.run(
                `
                UPDATE quests
                SET completed = 1
                WHERE id = ?
                `,
                [questId],
                function(updateError) {

                    if (updateError) {
                        return res.status(500).json({
                            message: "Could not complete quest"
                        });
                    }

                    db.run(
                        `
                        UPDATE characters
                        SET
                            xp = xp + ?,
                            coins = coins + ?,
                            streak = streak + 1
                        WHERE user_id = ?
                        `,
                        [
                            quest.xp,
                            quest.coins,
                            quest.user_id
                        ],
                        function(characterError) {

                            if (characterError) {
                                return res.status(500).json({
                                    message: "Could not update player progress"
                                });
                            }

                            res.json({
                                message: "Quest completed successfully",
                                earnedXP: quest.xp,
                                earnedCoins: quest.coins
                            });
                        }
                    );
                }
            );
        }
    );
});